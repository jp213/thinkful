Zenmode
=======

A little extension to give Zenmode functionality to the IPython notebook