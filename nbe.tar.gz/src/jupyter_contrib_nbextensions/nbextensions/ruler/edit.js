define(['./main'], function (ruler) {
    "use strict";
    return ruler;
});
