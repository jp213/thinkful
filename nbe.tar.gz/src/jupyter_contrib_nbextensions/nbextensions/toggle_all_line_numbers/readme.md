Toggle all line numbers
=======================
This extension adds a toolbar button, along with an optional hotkey,
to toggle all cells' line numbers on or off in one action.

