Export HTML With Embedded Images
================================
This extension allows exporting an embedded HTML by an additional download option in File -> Download -> HTML Embedded, (works like: jupyter nbconvert --to html_embed notebook.ipynb)

**Note**: This extension can so far only successfully read relative images paths in the markdown cells (e.g. `![](graphics/pic.png)`)  when jupyter is started in the same folder (working directory) where the relative paths can be resolved!
 

